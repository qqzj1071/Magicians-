"""Load a survival-v6 research checkpoint and validated damage schedule."""
import json
from pathlib import Path
import survival_tournament as Q


def load_model(checkpoint):
    data=json.loads(Path(checkpoint).read_text(encoding='utf-8'))
    if data.get('construction_profile')!='survival-v6':raise ValueError('Expected survival-v6 checkpoint')
    Q.A.install();model=Q.A.Learner(data);model.w=data['draft'];model.prior=data['prior'];model.updates=data['updates']
    return model


def load_table(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'));table=data.get('table',data)
    Q.validate_table(table);return table
