"""Versioned construction prices; battle mana and rarity odds are unchanged."""

REVISED='growth-v2'
LEGACY='legacy-v1'


def free_purchase_rarity(round_num, profile=REVISED):
    if profile==LEGACY:return None
    if profile!=REVISED:raise ValueError(profile)
    if 1<=round_num<=3:return 'common'
    if 4<=round_num<=6:return 'rare'
    return None


def purchase_price(base_price, rarity, round_num, free_used, profile=REVISED):
    return 0 if not free_used and rarity==free_purchase_rarity(round_num,profile) else base_price


def deletion_limit(round_num, profile=REVISED):
    if profile==LEGACY:return 1 if round_num<=5 else 2
    if profile!=REVISED:raise ValueError(profile)
    return 0 if round_num<=3 else 1 if round_num<=6 else 2


def deletion_price(round_num, deleted_this_round, profile=REVISED):
    if deleted_this_round>=deletion_limit(round_num,profile):return None
    if profile==LEGACY:return 0
    return 0 if round_num>=7 and deleted_this_round==0 else 1
