OBSOLETE / 已过时。仅供明确要求的历史追溯。不得作为现行规则或AI入口。当前版本：releases/deckbuilding-v1.0/。
