# Magicians! 当前工作约束

- 当前卡牌唯一版本为v1.0。先读docs/README.md，再读releases/v1.0/cards.json；docs/cards/*.md为生成视图，不是另一份版本。
- 默认不解压、不检索archives/pre-v1.0.zip，不引用旧版卡表、胜率、克制标签。用户明确要求追溯时才能恢复指定文件。
- 本轮卡牌已封版。后续构筑任务只调整流程/牌组，不隐含授权改卡牌；新版本调整须另行记录。
- 数值规范见docs/combat/numeric-standards.md：机制科学计数法尾数半单位；普通未选专精效果严格为已选专精一半；固定价值=攻+1.5防，同稀有度差距≤20%。
- decks/decks.json是15套旧构筑参考列表，不能当成正式构筑流程限制。构筑讨论起点见docs/deckbuilding/process-draft.md。
- 战斗运行器在tools/round_robin，当前只验证单主系加通用的双人模拟；混系传奇机制和多人赛事尚未完整实现。既有AI权重并非全部在最新卡表验证。
- 改卡表或构筑后必须重新校准所涉对局；不得混用旧结论制造达标。运行python tools/round_robin/verify_v1.py检查封版与回归。
