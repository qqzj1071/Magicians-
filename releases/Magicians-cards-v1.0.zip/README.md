# Magicians!

当前卡牌版本：**v1.0**。请从[文档入口](docs/README.md)开始。

唯一卡牌数据：releases/v1.0/cards.json；文档卡表是生成视图。旧版本已压缩封存，默认不读取。下一阶段工作是重新讨论卡组构筑流程。
