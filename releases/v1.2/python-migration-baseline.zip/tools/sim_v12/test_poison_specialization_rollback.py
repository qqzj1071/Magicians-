import unittest
from .test_current import setup

class PoisonSpecializationRollback(unittest.TestCase):
 def test_dynamic_point_five_defense_reduction_floors_clamps_and_clears(self):
  b=setup('瘟疫领主');s,e=b.players;s.active.add('瘟疫领主')
  for own,target,expected in ((0,0,(100,40)),(0,2,(95,35)),(3,1,(94,34)),(10,3,(77,20)),(100,5,(0,0)),(10,0,(100,40))):
   s.layers['poison']=own;e.poison=target
   self.assertEqual(b.stats(1),expected)
   self.assertEqual((e.attack,e.defense),(100,40))
 def test_bone_override_stays_one_point_two_and_point_nine(self):
  b=setup('瘟疫领主');s,e=b.players;s.active.update(('瘟疫领主','附骨之毒'));s.layers['poison']=10;e.poison=3
  self.assertEqual(b.stats(1),(59,8))
  s.active.remove('附骨之毒');self.assertEqual(b.stats(1),(77,20))
  e.poison=0;self.assertEqual(b.stats(1),(100,40))
