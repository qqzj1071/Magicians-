"""Mechanism features; own composition and revealed choices, no hidden order."""
from collections import Counter
from functools import lru_cache
import re
from .catalog import CARDS
from .panel_budget import role as panel_role
DRAW_N = {'速读': 1, '掠影': 1, '活水': 1, '添柴': 1, '回炉重造': 2, '燃页': 1, '火种书签': 2, '观潮': 1, '毒涌': 1.5, '循毒': 1, '毒物滋养': 0.5, '狂风': 3, '神行': 1, '捕风': 1, '追云': 2, '追风': 1, '借风': 1, '风驰': 2, '风过留痕': 2, '风之躯': 1, '灵感涌现': 2, '通晓': 2, '翻阅': 2, '禁咒目录': 2, '凿石': 0.7, '狂战': 1, '换页': 1}
FEE_N = {'灵感涌现': 1, '狂风': 1, '借风': 0.7, '风驰': 1.5, '顺风': 0.7, '毒物滋养': 0.6, '战术': 0.4}
SEARCH_N = {'检索附魔': 1, '听风': 1, '探脉': 1, '寻药': 1, '塑水': 1, '逐火': 1, '大检索': 2, '命运检索': 2, '深潜': 1, '潮汐回廊': 1, '问山': 1}
DISCARD_N = {'通晓': 1, '坚壁': 1, '包扎': 1, '狂战': 1, '换页': 1, '护盾强化': 1, '蓄能': 1}
SHUFFLES = {'重洗', '循环', '盾之共鸣', '回炉重造', '拨灰续火'}
FUTURE = {'循环': (1, 1), '禁忌知识': (2, 1), '战神徽记': (0.8, 0), '守护者壁垒': (0, 0.25), '恐惧': (1, 0), '预备': (-1, 1), '整理': (2, -1), '蓄能': (1, 0), '翻阅': (-1, 0), '听潮': (0, 0), '凭潮': (0, 1.2), '烬中搏动': (0.7, 0), '试我火候': (0.5, 0), '灰烬账本': (1.5, 0)}
PASSIVES = {'时光倒流': 5, '永恒壁垒': 2, '战神徽记': 3, '守护者壁垒': 1.3, '禁忌知识': 2, '风暴': 4, '身为洪炉': 3, '灰烬循环': 4, '潮汐回响': 4, '生命之泉': 5, '浴血狂澜': 3, '破而后立': 4, '以守为攻': 4, '聚砾成锋': 4, '长风不息': 4, '穿云破阵': 4, '积风成灾': 4, '以毒淬锋': 4, '蚕食生机': 4, '附骨之毒': 4, '一息尚存': 2, '积土成山': 1.0, '步步为营': 1.0, '涌泉': 1.2, '深渊': 1.5, '烈风': 1.5, '慢性毒药': 0.96}

@lru_cache(None)
def static(name):
    c = CARDS[name]
    t = c.text
    role = panel_role(name)
    shield = sum(map(int, re.findall('获得(\\d+)(?:普通|临时)?护盾', t)))
    heal = sum(map(int, re.findall('回复(\\d+)生命', t)))
    delay = sum(map(float, re.findall('(?:间隔减少|间隔永久减少)(\\d+(?:\\.\\d+)?)', t)))
    if name == '长风不息':delay = 0
    if name in ('短促', '催火', '迅捷', '神行', '烈风'):
        delay = {'短促': 5, '催火': 10, '迅捷': 7.5, '神行': 10, '烈风': 2.5}[name]
    return dict(draw=DRAW_N.get(name, 0), fee=FEE_N.get(name, 0), search=SEARCH_N.get(name, 0), discard=DISCARD_N.get(name, 0), shuffle=float(name in SHUFFLES), recover=float(name in ('拾火', '循毒')), future_draw=FUTURE.get(name, (0, 0))[0], future_fee=FUTURE.get(name, (0, 0))[1], passive=PASSIVES.get(name, 0), shield=shield / 50, heal=heal / 40, delay=delay / 5,panel_role=role)

@lru_cache(maxsize=20000)
def composition(names):
    counts = Counter(names)
    total = max(1, len(names))
    draw = sum((static(n)['draw'] * k for n, k in counts.items())) / total
    fee = sum((static(n)['fee'] * k for n, k in counts.items())) / total
    cheap = sum((k for n, k in counts.items() if CARDS[n].cost <= 1)) / total
    return (draw, fee, cheap)

def dynamic(b, s, name):
    f = dict(static(name))
    e = b.players[1 - s.seat]
    if name == '长风不息':
        f['delay'] = (4+s.layers['wind']/2)/5
    if name == '活水':
        f['draw'] = int(s.hp < s.max_hp)
    elif name == '毒涌':
        f['draw'] = 2 if e.poison else 1
    elif name == '毒物滋养':
        f['draw'] = int(e.poison + 2 >= 6)
        f['fee'] = int(e.poison + 2 >= 3)
    elif name == '凿石':
        f['draw'] = int(s.shield_total >= 30)
    elif name == '风驰':
        f['fee'] = 2 if b.gap(s) <= 30 else 1
    elif name == '借风':
        f['fee'] = int(any((x.name == name and x.uid not in s.seen for x in s.hand)))
    elif name == '顺风':
        f['fee'] = int(s.counts['wind'] >= 2 and (not s.fx['tailwind_used']))
    elif name == '风过留痕':
        f['draw'] = 0 if s.has('积风成灾') else 2
    elif name == '战术':
        f['fee'] = int(s.energy == 0 and (not s.fx['tactic_used']))
    elif name == '凭潮':
        f['future_fee'] = 2 if s.tide >= 30 else 0
    elif name == '循毒':
        if e.poison >= 3 and any((CARDS[x.name].element == 'poison' and CARDS[x.name].enchantment for x in s.discard)):
            f['draw'] = 0
            f['recover'] = 1
        else:
            f['draw'] = 1
            f['recover'] = 0
    if name in ('拾火', '循毒') and (not s.discard):
        f['recover'] = 0
    return f
