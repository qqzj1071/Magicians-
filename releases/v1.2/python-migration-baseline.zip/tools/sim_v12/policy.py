"""v1.2 public-information heuristic policy; no v1.1 weights or card lists."""
from collections import Counter
from .catalog import CARDS, ELEMENTS, ROUTES, SPECIAL, START, RANK
DRAW = frozenset(('速读', '掠影', '活水', '添柴', '回炉重造', '燃页', '火种书签', '观潮', '毒涌', '循毒', '毒物滋养', '狂风', '神行', '捕风', '追云', '追风', '借风', '风驰', '风过留痕', '风之躯', '灵感涌现', '通晓', '翻阅', '禁咒目录', '凿石'))
SHUFFLE = frozenset(('重洗', '循环', '盾之共鸣', '回炉重造', '拨灰续火'))
SEARCH = frozenset(('检索附魔', '听风', '探脉', '寻药', '塑水', '逐火', '大检索', '命运检索', '深潜', '潮汐回廊', '问山'))
SUPPORT = {'焚天神兵': ('聚爆', '高温炉芯', '怒焰', '炽焰', '高温炼化'), '灰烬循环': ('回炉重造', '拨灰续火', '回灶', '添柴', '灰烬账本', '火种书签'), '身为洪炉': ('吞烬', '烬中搏动', '余温护心', '高温炉芯'), '生命之泉': ('湍流', '浸润', '破浪', '活水', '听潮', '回响之潮'), '潮汐回响': ('回响之潮', '洪潮', '深渊', '涟漪', '泉眼'), '浴血狂澜': ('血刃', '溯洄', '背水', '血潮汹涌'), '破而后立': ('万钧碎盾', '固若金汤', '屡毁屡筑', '补墙', '碎盾术', '步步为营'), '以守为攻': ('积土成山', '步步为营', '倚石养息', '平地起垒'), '聚砾成锋': ('砺石', '碎石借势', '夯实', '积土成山', '挟山一击'), '长风不息': ('烈风', '疾风连斩', '神行', '追风', '迅捷'), '穿云破阵': ('风蚀', '裂空穿云', '风暴', '裂风'), '积风成灾': ('风过留痕', '风痕刻印', '风暴', '裂风', '疾风连斩', '狂风'), '以毒淬锋': ('毒爆', '烈性反应', '固毒', '毒涌', '蛇吻', '毒针'), '蚕食生机': ('蚀心', '溃败', '慢性毒药', '涂毒'), '附骨之毒': ('万毒蚀骨', '毒入膏肓', '疫病', '催枯', '蚀创')}

def targets():
    result = {}
    for element in ELEMENTS:
        for route in ROUTES[element]:
            support = list(SUPPORT[route])
            extra = sorted((n for n, c in CARDS.items() if c.element == element and c.enchantment and (n not in support)), key=lambda n: (n in DRAW, n in SEARCH, CARDS[n].cost <= 1, CARDS[n].layers), reverse=True)
            learned = [SPECIAL[element], route] + support + extra[:4] + ['灵感涌现', '通晓', '盾之共鸣']
            result[route] = dict(element=element, route=route, entries=list(START) + list(dict.fromkeys(learned)))
    assert len(result) == 15
    assert all((n in CARDS for d in result.values() for n in d['entries']))
    return result
TARGETS = targets()
STYLES = {'balanced': dict(attack=1.0, defense=1.5, draw=20, search=8, shuffle=5, layer=12, curve=0.4, support=8, refresh=8), 'aggressive': dict(attack=1.6, defense=0.8, draw=14, search=6, shuffle=3, layer=10, curve=0.25, support=6, refresh=7), 'defensive': dict(attack=0.7, defense=2.4, draw=16, search=10, shuffle=6, layer=12, curve=0.4, support=8, refresh=9), 'tempo': dict(attack=1.0, defense=1.1, draw=26, search=8, shuffle=4, layer=13, curve=0.8, support=6, refresh=9), 'engine': dict(attack=0.8, defense=1.2, draw=36, search=16, shuffle=14, layer=10, curve=0.5, support=7, refresh=10), 'synergy': dict(attack=1.0, defense=1.5, draw=18, search=14, shuffle=7, layer=16, curve=0.35, support=16, refresh=8)}
STYLE_LABELS = {'balanced': '均衡', 'aggressive': '进攻', 'defensive': '防守', 'tempo': '节奏', 'engine': '运转', 'synergy': '协同'}

def choose_play(battle, i):
    s, enemy = (battle.players[i], battle.players[1 - i])
    style = STYLES[battle.styles[i]]
    affordable = [x for x in s.hand if battle.cost(s, x) <= s.energy]
    if not affordable:
        return None

    def score(x):
        c = CARDS[x.name]
        value = 10 + c.attack * style['attack'] + c.defense * style['defense']
        if x.uid not in s.seen:
            value += c.layers * style['layer']
        if c.kind == 'specialization':
            value += 150
        if c.kind == 'route_legendary':
            value += 80
        if x.name in DRAW:
            value += style['draw']
        if x.name in SEARCH:
            value += style['search']
        if x.name in SHUFFLE:
            value += style['shuffle']
        if x.name == '一息尚存':
            value += 60 if s.hp < 300 else -8
        if x.name == '顺风' and s.counts['wind'] < 2:
            value -= 25
        if x.name == '战术':
            value -= 80
        if x.name in ('包扎', '坚壁', '狂战') and len(s.hand) <= 1:
            value -= 10
        if x.name == '润物' and s.hp * 2 <= s.max_hp:
            value += 10
        if x.name in ('毒爆', '烈性反应') and enemy.poison == 0:
            value -= 15
        return (value / max(1, battle.cost(s, x)) ** style['curve'], x.uid)
    return max(affordable, key=score)

def draft_value(player, name, public):
    c = CARDS[name]
    counts = Counter((CARDS[n].element for n, t in player.deck))
    style = STYLES[getattr(player, 'style', 'balanced')]
    focus = player.spec or max(ELEMENTS, key=lambda e: (counts[e], e == player.preference))
    route = player.route
    value = (c.attack * style['attack'] + c.defense * style['defense']) / ((c.cost + 1) / 2) / 3 + (7 if c.element == focus else 0 if c.element == 'generic' else -3)
    if not player.spec and c.enchantment and (c.element == focus):
        value += 3 + counts[focus] * 3
    if c.name in DRAW:
        value += style['draw'] / 5
    if c.name in SEARCH:
        value += style['search'] / 8
    if c.name in SHUFFLE and (not any((n in SHUFFLE for n, t in player.deck))):
        value += style['shuffle'] / 2
    if route and name in SUPPORT[route]:
        value += style['support']
    if c.kind == 'route_legendary':
        occupied = {p['route'] for p in public if p['pid'] != player.pid}
        if name in occupied:
            return -100
        value += 12 if not route else 8 if name in SUPPORT.get(route, ()) else -12
        value += sum((n in SUPPORT[name] for n, t in player.deck)) * 2
    value -= max(0, len(player.deck) - 18) * 0.6
    return value
from .learning_policy import choose_play, draft_value, choose_cards
