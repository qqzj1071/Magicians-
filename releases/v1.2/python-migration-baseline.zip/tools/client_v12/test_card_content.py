import json
import unittest
from tools.sim_v12.catalog import CARDS, ROOT, copies
from tools.client_v12.bridge import card_view
from types import SimpleNamespace


class CardContentTests(unittest.TestCase):
    def test_all_element_legendary_and_specialization_cards_have_exact_flavor(self):
        flavor = json.loads((ROOT / 'Data/Presentation/card-flavor.json').read_text(encoding='utf-8'))['cards']
        expected = {n for n, c in CARDS.items() if c.element != 'generic' and c.rarity in ('legendary', 'specialization')}
        self.assertEqual(set(flavor), expected)
        self.assertEqual(len(flavor), 25)
        self.assertTrue(all(isinstance(s, str) and s.strip() for s in flavor.values()))

    def test_canonical_names_are_authoritative_in_catalog_and_instance_payloads(self):
        for name in ('聚烬成焰', '星火燎原', '沧海横流', '浴血狂澜', '试我火候', '附骨之毒'):
            with self.subTest(name=name):
                card = CARDS[name]
                self.assertEqual(card.name, name)
                self.assertEqual(card_view(SimpleNamespace(uid=1, name=name))['name'], name)
        self.assertEqual(len(CARDS), 183)
        self.assertEqual(sum(copies(c) for c in CARDS.values()), 677)
